import discord
from discord.ext import commands
import ai_model
import requests

intents = discord.Intents.default()
intents.message_content = True
intents.members = True

bot = commands.Bot(command_prefix='$' , intents=intents)

@bot.event
async def on_ready():
    print('----------------------------')
    print(f'Hazırım Kaptan ben : {bot.user}')
    print('----------------------------')

@bot.command()
async def hello(ctx):
    await ctx.send('Hoşgeldin Beni kullanmaya hazır mısın?($hazırım)')

@bot.command()
async def hazırım(ctx):
    await ctx.send('Resim ekleyerek ve eklediğin resim mesajına $resim yazarak dosyanı gönderebilirsin')   

@bot.command()
async def resim(ctx):
    if ctx.message.attachments:
        for attachment in ctx.message.attachments:
            file_name = attachment.filename
            file_url = attachment.url
            await attachment.save(f'./{attachment.filename}')
            await ctx.send(f'resim kaydedildi : {attachment.filename}')
            ai_model.ayirt(file_name)

            sinif,tahmin = ai_model.ayirt(file_name)
            await  ctx.send(f"sinif:{sinif},tahmin:{tahmin}")

    else:
        print("Resim yok")
























bot.run("MTIxMTcxMDg4NTc4NjE2MTIzMg.GxtOfw.JdwBkGDFgdLhdxDDNXJCTOBwnddrXu5qj1NXjU")